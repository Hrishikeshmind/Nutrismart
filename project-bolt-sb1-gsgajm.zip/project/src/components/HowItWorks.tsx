import React from 'react';
import { Smartphone, ClipboardCheck, Salad, Trophy } from 'lucide-react';

const steps = [
  {
    icon: <Smartphone className="h-8 w-8" />,
    title: 'Download & Sign Up',
    description: 'Get started with our easy-to-use mobile app and create your personalized profile.'
  },
  {
    icon: <ClipboardCheck className="h-8 w-8" />,
    title: 'Set Your Goals',
    description: 'Tell us about your health objectives and dietary preferences.'
  },
  {
    icon: <Salad className="h-8 w-8" />,
    title: 'Follow Your Plan',
    description: 'Receive customized meal plans and nutrition guidance tailored to your needs.'
  },
  {
    icon: <Trophy className="h-8 w-8" />,
    title: 'Achieve Results',
    description: 'Track your progress and celebrate your health victories.'
  }
];

export default function HowItWorks() {
  return (
    <section className="py-24 bg-gradient-to-b from-white to-emerald-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Your Path to Better Health
          </h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Getting started with NutriSmart is simple. Follow these steps to begin your journey towards a healthier lifestyle.
          </p>
        </div>

        <div className="mt-20">
          <div className="relative">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-emerald-300" />
            </div>
            <div className="relative flex justify-between">
              {steps.map((step, index) => (
                <div key={index} className="bg-emerald-50 p-4 rounded-full">
                  <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center text-white">
                    {step.icon}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-4">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <h3 className="mt-6 text-xl font-semibold text-gray-900">{step.title}</h3>
                <p className="mt-2 text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}