import React from 'react';

const stats = [
  { number: '10K+', label: 'Active Users' },
  { number: '500+', label: 'Nutrition Plans' },
  { number: '1M+', label: 'Meals Tracked' },
  { number: '98%', label: 'Success Rate' }
];

export default function Stats() {
  return (
    <section className="bg-emerald-500">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <p className="text-4xl font-bold text-white">{stat.number}</p>
              <p className="mt-2 text-sm text-emerald-100">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}