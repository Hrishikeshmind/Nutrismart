import React from 'react';
import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Basic',
    price: '9.99',
    features: [
      'Personalized meal plans',
      'Basic nutrition tracking',
      'Recipe database access',
      'Email support'
    ]
  },
  {
    name: 'Pro',
    price: '19.99',
    popular: true,
    features: [
      'Everything in Basic',
      'Advanced analytics',
      'Custom recipe creation',
      'Priority support',
      'Meal prep guides',
      'Community access'
    ]
  },
  {
    name: 'Enterprise',
    price: '49.99',
    features: [
      'Everything in Pro',
      'Personal nutrition coach',
      'Custom meal plans',
      'Weekly consultations',
      'Family accounts',
      'API access'
    ]
  }
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Choose Your Plan
          </h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Select the perfect plan for your health journey. All plans include our core features with the flexibility to upgrade anytime.
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 lg:grid-cols-3">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-2xl ${
                plan.popular
                  ? 'bg-white ring-2 ring-emerald-500 shadow-xl'
                  : 'bg-white shadow-lg'
              }`}
            >
              {plan.popular && (
                <span className="absolute top-0 right-6 -translate-y-1/2 rounded-full bg-emerald-500 px-4 py-1 text-sm font-semibold text-white">
                  Popular
                </span>
              )}
              <div className="p-8">
                <h3 className="text-xl font-semibold text-gray-900">{plan.name}</h3>
                <p className="mt-4 flex items-baseline">
                  <span className="text-4xl font-bold tracking-tight text-gray-900">
                    ${plan.price}
                  </span>
                  <span className="ml-1 text-sm font-semibold text-gray-500">/month</span>
                </p>
                <ul className="mt-8 space-y-4">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="h-5 w-5 text-emerald-500" />
                      <span className="ml-3 text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  className={`mt-8 w-full rounded-full py-3 px-6 text-center font-semibold ${
                    plan.popular
                      ? 'bg-emerald-500 text-white hover:bg-emerald-600'
                      : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                  } transition-colors`}
                >
                  Get Started
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}