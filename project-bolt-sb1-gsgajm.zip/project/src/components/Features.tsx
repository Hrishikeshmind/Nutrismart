import React from 'react';
import { Brain, Calendar, LineChart, Utensils } from 'lucide-react';

const features = [
  {
    icon: <Brain className="h-6 w-6" />,
    title: 'Smart Nutrition Analysis',
    description: 'AI-powered insights to help you make better food choices tailored to your needs.'
  },
  {
    icon: <Calendar className="h-6 w-6" />,
    title: 'Meal Planning',
    description: 'Create personalized meal plans that fit your lifestyle and dietary requirements.'
  },
  {
    icon: <LineChart className="h-6 w-6" />,
    title: 'Progress Tracking',
    description: 'Monitor your health journey with detailed analytics and insights.'
  },
  {
    icon: <Utensils className="h-6 w-6" />,
    title: 'Recipe Database',
    description: 'Access thousands of healthy recipes curated by nutrition experts.'
  }
];

export default function Features() {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Smart Features for Your Health Journey
          </h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Discover how NutriSmart can help you achieve your health and nutrition goals with our comprehensive suite of features.
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <div
              key={index}
              className="relative group bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl opacity-0 group-hover:opacity-100 transition duration-300 blur"></div>
              <div className="relative bg-white p-6 rounded-xl">
                <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-500">
                  {feature.icon}
                </div>
                <h3 className="mt-4 text-xl font-semibold text-gray-900">{feature.title}</h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}