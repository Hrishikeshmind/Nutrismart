import React, { useState } from 'react';
import { ChefHat, Clock, Flame, Heart, Salad, Sparkles } from 'lucide-react';

const dietaryPreferences = [
  'Vegetarian',
  'Vegan',
  'Keto',
  'Paleo',
  'Mediterranean',
  'Low-Carb'
];

const mealTypes = [
  'Breakfast',
  'Lunch',
  'Dinner',
  'Snack'
];

const sampleMeals = {
  'Breakfast': {
    title: 'Protein-Packed Quinoa Bowl',
    calories: 420,
    time: '15 mins',
    image: 'https://images.unsplash.com/photo-1490474504059-bf2db5ab2348?auto=format&fit=crop&q=80&w=400&h=300',
    ingredients: ['Quinoa', 'Eggs', 'Avocado', 'Cherry Tomatoes', 'Baby Spinach']
  },
  'Lunch': {
    title: 'Mediterranean Power Salad',
    calories: 380,
    time: '20 mins',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=400&h=300',
    ingredients: ['Mixed Greens', 'Grilled Chicken', 'Feta', 'Olives', 'Cucumber']
  },
  'Dinner': {
    title: 'Herb-Crusted Salmon',
    calories: 450,
    time: '25 mins',
    image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&q=80&w=400&h=300',
    ingredients: ['Salmon Fillet', 'Fresh Herbs', 'Quinoa', 'Roasted Vegetables']
  },
  'Snack': {
    title: 'Energy-Boosting Trail Mix',
    calories: 200,
    time: '5 mins',
    image: 'https://images.unsplash.com/photo-1599598425947-5202edd56bdb?auto=format&fit=crop&q=80&w=400&h=300',
    ingredients: ['Almonds', 'Walnuts', 'Dried Cranberries', 'Dark Chocolate']
  }
};

export default function MealGenerator() {
  const [selectedDiet, setSelectedDiet] = useState('');
  const [selectedMealType, setSelectedMealType] = useState('');
  const [generatedMeal, setGeneratedMeal] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    // Simulate AI generation delay
    setTimeout(() => {
      setGeneratedMeal(sampleMeals[selectedMealType]);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="h-8 w-8 text-emerald-500 mr-2" />
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
              AI Meal Generator
            </h2>
          </div>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Get personalized meal suggestions based on your dietary preferences and nutritional goals.
          </p>
        </div>

        <div className="mt-12 max-w-3xl mx-auto">
          <div className="bg-white shadow-xl rounded-2xl p-8">
            <div className="space-y-6">
              <div>
                <label className="text-lg font-medium text-gray-900">Dietary Preference</label>
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {dietaryPreferences.map((diet) => (
                    <button
                      key={diet}
                      onClick={() => setSelectedDiet(diet)}
                      className={`px-4 py-2 rounded-full text-sm font-medium ${
                        selectedDiet === diet
                          ? 'bg-emerald-500 text-white'
                          : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                      } transition-colors`}
                    >
                      {diet}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-lg font-medium text-gray-900">Meal Type</label>
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {mealTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedMealType(type)}
                      className={`px-4 py-2 rounded-full text-sm font-medium ${
                        selectedMealType === type
                          ? 'bg-emerald-500 text-white'
                          : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                      } transition-colors`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleGenerate}
                disabled={!selectedDiet || !selectedMealType || isGenerating}
                className="w-full py-3 px-6 rounded-full bg-emerald-500 text-white font-medium hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isGenerating ? (
                  <div className="flex items-center justify-center">
                    <ChefHat className="animate-bounce h-5 w-5 mr-2" />
                    Generating your meal...
                  </div>
                ) : (
                  'Generate Meal Suggestion'
                )}
              </button>
            </div>

            {generatedMeal && !isGenerating && (
              <div className="mt-8 bg-gray-50 rounded-xl p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <img
                    src={generatedMeal.image}
                    alt={generatedMeal.title}
                    className="w-full md:w-1/2 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-gray-900">{generatedMeal.title}</h3>
                    <div className="mt-4 flex items-center space-x-4">
                      <div className="flex items-center">
                        <Flame className="h-5 w-5 text-emerald-500 mr-1" />
                        <span>{generatedMeal.calories} cal</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-5 w-5 text-emerald-500 mr-1" />
                        <span>{generatedMeal.time}</span>
                      </div>
                      <div className="flex items-center">
                        <Heart className="h-5 w-5 text-emerald-500 mr-1" />
                        <span>{selectedDiet}</span>
                      </div>
                    </div>
                    <div className="mt-6">
                      <h4 className="font-semibold text-gray-900">Ingredients:</h4>
                      <ul className="mt-2 space-y-2">
                        {generatedMeal.ingredients.map((ingredient, index) => (
                          <li key={index} className="flex items-center">
                            <Salad className="h-4 w-4 text-emerald-500 mr-2" />
                            {ingredient}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}