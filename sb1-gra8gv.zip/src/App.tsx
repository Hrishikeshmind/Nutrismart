import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import NutritionForm from './components/NutritionForm';
import Login from './components/Auth/Login';
import MealPlanner from './components/Dashboard/MealPlanner';
import ProgressTracker from './components/Dashboard/ProgressTracker';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
}

function App() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-white">
        <Header />
        <Routes>
          <Route
            path="/"
            element={
              <main>
                <Hero />
                <Features />
                <NutritionForm />
              </main>
            }
          />
          <Route path="/login" element={<Login />} />
          <Route
            path="/meal-planner"
            element={
              <PrivateRoute>
                <MealPlanner />
              </PrivateRoute>
            }
          />
          <Route
            path="/progress"
            element={
              <PrivateRoute>
                <ProgressTracker />
              </PrivateRoute>
            }
          />
        </Routes>
        
        <footer className="bg-gray-50 border-t border-gray-100 py-8">
          <div className="container mx-auto px-4 text-center text-gray-600">
            <p>© 2024 NutriSmart. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  );
}

export default App;