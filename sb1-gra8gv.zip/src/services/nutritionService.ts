import OpenAI from 'openai';
import { NutritionFormData, NutritionPlanResult } from './types';
import { calculateBasicPlan } from './nutritionCalculator';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export async function generateNutritionPlan(formData: NutritionFormData): Promise<NutritionPlanResult> {
  try {
    if (!import.meta.env.VITE_OPENAI_API_KEY) {
      return {
        plan: calculateBasicPlan(formData),
        source: 'calculator',
        notice: 'Using our standard nutrition calculator.'
      };
    }

    const prompt = `Create a personalized nutrition plan for someone with the following characteristics:
- Age: ${formData.age}
- Weight: ${formData.weight}kg
- Dietary Preferences: ${formData.dietaryPreferences}
- Health Goals: ${formData.healthGoals.join(', ')}

Please provide a detailed but concise nutrition plan including:
1. Daily caloric needs
2. Macronutrient breakdown
3. Key food recommendations
4. Meal timing suggestions
5. Specific considerations based on their goals`;

    const completion = await openai.chat.completions.create({
      messages: [
        { 
          role: 'system', 
          content: 'You are a professional nutritionist providing personalized nutrition plans. Be specific, practical, and evidence-based in your recommendations.'
        },
        { role: 'user', content: prompt }
      ],
      model: 'gpt-3.5-turbo',
      temperature: 0.7,
      max_tokens: 500
    });

    const aiPlan = completion.choices[0].message.content;
    
    if (!aiPlan) {
      throw new Error('Failed to generate AI response');
    }

    return {
      plan: aiPlan,
      source: 'ai'
    };

  } catch (error: any) {
    console.error('Nutrition Service Error:', error);

    // Handle quota exceeded error specifically
    if (error?.error?.type === 'insufficient_quota' || error?.error?.code === 'insufficient_quota') {
      return {
        plan: calculateBasicPlan(formData),
        source: 'calculator',
        notice: 'Our AI service is currently at capacity. Using our standard nutrition calculator instead.'
      };
    }

    // Handle all other errors
    return {
      plan: calculateBasicPlan(formData),
      source: 'calculator',
      notice: 'Temporarily using our standard nutrition calculator. Please try again in a few minutes for AI-powered recommendations.'
    };
  }
}