import { NutritionFormData } from './types';

export function calculateBasicPlan(data: NutritionFormData): string {
  // Calculate BMR using Mifflin-St Jeor Equation
  const bmr = 10 * data.weight + 6.25 * 170 - 5 * data.age + 5; // Assuming average height
  
  // Adjust calories based on goals
  let calories = bmr;
  if (data.healthGoals.includes('Weight Loss')) {
    calories *= 0.85; // 15% deficit
  } else if (data.healthGoals.includes('Muscle Gain')) {
    calories *= 1.15; // 15% surplus
  }

  // Calculate macros
  let protein = data.weight * 2; // 2g per kg
  let fat = (calories * 0.25) / 9; // 25% of calories from fat
  let carbs = (calories - (protein * 4 + fat * 9)) / 4;

  // Adjust for dietary preferences
  if (data.dietaryPreferences === 'keto') {
    fat = (calories * 0.75) / 9;
    carbs = 20; // Fixed 20g carbs for keto
    protein = (calories - (fat * 9 + carbs * 4)) / 4;
  }

  return `Based on your profile, here's your personalized nutrition plan:

1. Daily Caloric Needs: ${Math.round(calories)} calories

2. Macronutrient Breakdown:
   • Protein: ${Math.round(protein)}g
   • Carbohydrates: ${Math.round(carbs)}g
   • Fat: ${Math.round(fat)}g

3. Key Food Recommendations:
   ${getFoodRecommendations(data.dietaryPreferences)}

4. Meal Timing:
   • Breakfast: 25% of daily calories (${Math.round(calories * 0.25)} cal)
   • Lunch: 35% of daily calories (${Math.round(calories * 0.35)} cal)
   • Dinner: 30% of daily calories (${Math.round(calories * 0.30)} cal)
   • Snacks: 10% of daily calories (${Math.round(calories * 0.10)} cal)

5. Additional Recommendations:
   ${getAdditionalRecommendations(data.healthGoals)}`;
}

function getFoodRecommendations(dietaryPreference: string): string {
  const recommendations = {
    omnivore: '• Lean meats (chicken, fish)\n   • Whole grains\n   • Vegetables\n   • Fruits\n   • Healthy fats (olive oil, avocados)',
    vegetarian: '• Legumes\n   • Eggs and dairy\n   • Whole grains\n   • Nuts and seeds\n   • Plant-based proteins',
    vegan: '• Legumes and beans\n   • Quinoa and whole grains\n   • Nuts and seeds\n   • Plant-based proteins\n   • Fortified foods',
    keto: '• Fatty fish\n   • Eggs\n   • Healthy oils\n   • Low-carb vegetables\n   • Nuts and seeds',
    paleo: '• Lean meats\n   • Fish\n   • Fruits\n   • Vegetables\n   • Nuts and seeds'
  };
  
  return recommendations[dietaryPreference as keyof typeof recommendations] || recommendations.omnivore;
}

function getAdditionalRecommendations(goals: string[]): string {
  const recommendations = [];
  
  if (goals.includes('Weight Loss')) {
    recommendations.push('Focus on high-protein foods to maintain muscle mass during caloric deficit');
  }
  if (goals.includes('Muscle Gain')) {
    recommendations.push('Consume protein-rich meals every 3-4 hours');
  }
  if (goals.includes('Better Health')) {
    recommendations.push('Include a variety of colorful vegetables for optimal nutrient intake');
  }
  if (goals.includes('More Energy')) {
    recommendations.push('Space your meals evenly throughout the day to maintain stable energy levels');
  }
  if (goals.includes('Sports Performance')) {
    recommendations.push('Time your carbohydrate intake around your training sessions');
  }

  return recommendations.join('\n   ') || 'Maintain consistent meal timing and stay hydrated throughout the day';
}