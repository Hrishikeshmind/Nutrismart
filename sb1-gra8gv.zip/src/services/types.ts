export interface NutritionFormData {
  age: number;
  weight: number;
  dietaryPreferences: string;
  healthGoals: string[];
}

export interface NutritionPlanResult {
  plan: string;
  source: 'ai' | 'calculator';
  notice?: string;
}