export const SYSTEM_PROMPTS = {
  NUTRITION_ASSISTANT: `You are NutriSmart AI, an expert nutrition assistant. You provide personalized nutrition advice, meal planning suggestions, and health recommendations. Keep responses concise, practical, and evidence-based. Focus on:
- Personalized nutrition advice
- Meal planning and recipes
- Dietary recommendations
- Health goal guidance
- Scientific, evidence-based information`,
  PLAN_GENERATOR: 'You are a professional nutritionist providing personalized nutrition plans. Be specific, practical, and evidence-based in your recommendations.'
};

export const ERROR_MESSAGES = {
  QUOTA_EXCEEDED: "We're currently experiencing high demand. Using our backup nutrition calculator for now. Try again in a few minutes for AI-powered recommendations.",
  GENERAL_ERROR: "We're having trouble connecting to our AI service. Using our backup nutrition calculator instead.",
  API_KEY_MISSING: "API configuration error. Please contact support."
};