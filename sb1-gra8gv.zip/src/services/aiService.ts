import OpenAI from 'openai';
import { ChatMessage, ApiError } from './types';
import { SYSTEM_PROMPTS, ERROR_MESSAGES } from './constants';

const apiKey = import.meta.env.VITE_OPENAI_API_KEY;

if (!apiKey) {
  throw new Error(ERROR_MESSAGES.API_KEY_MISSING);
}

const openai = new OpenAI({
  apiKey,
  dangerouslyAllowBrowser: true
});

export async function getAiResponse(messages: ChatMessage[]): Promise<string> {
  try {
    const completion = await openai.chat.completions.create({
      messages: [
        { role: 'system', content: SYSTEM_PROMPTS.NUTRITION_ASSISTANT },
        ...messages
      ],
      model: 'gpt-3.5-turbo',
      temperature: 0.7,
      max_tokens: 200
    });

    return completion.choices[0].message.content || ERROR_MESSAGES.GENERAL_ERROR;
  } catch (error) {
    const apiError = error as ApiError;
    
    if (apiError.type === 'insufficient_quota') {
      throw new Error(ERROR_MESSAGES.QUOTA_EXCEEDED);
    }
    
    throw new Error(ERROR_MESSAGES.GENERAL_ERROR);
  }
}