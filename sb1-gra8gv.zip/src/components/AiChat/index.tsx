import React, { useState, useRef, useEffect } from 'react';
import { Bot, Loader2, X, Maximize2, Minimize2 } from 'lucide-react';
import { getAiResponse, ChatMessage } from '../../services/aiService';
import AiMessage from './AiMessage';
import UserMessage from './UserMessage';
import ChatInput from './ChatInput';

export default function AiChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    if (isLoading) return;

    const userMessage: ChatMessage = { role: 'user', content };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const aiResponse = await getAiResponse([...messages, userMessage]);
      setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
    } catch (error) {
      console.error('Failed to get AI response:', error);
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: 'I apologize, but I encountered an error. Please try again later.'
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-green-600 text-white p-4 rounded-full shadow-lg hover:bg-green-700 transition-colors flex items-center gap-2"
      >
        <Bot className="h-6 w-6" />
        <span className="font-medium">Chat with AI Nutritionist</span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col border border-green-100">
      <div className="p-4 border-b border-gray-100 bg-green-50 rounded-t-2xl flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Bot className="h-6 w-6 text-green-600" />
          <h3 className="font-semibold text-gray-900">NutriSmart AI Assistant</h3>
        </div>
        <button
          onClick={() => setIsOpen(false)}
          className="text-gray-500 hover:text-gray-700 transition-colors"
        >
          <Minimize2 className="h-5 w-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center text-gray-500 mt-4">
            <p>👋 Hello! I'm your AI nutritionist.</p>
            <p className="mt-2">Ask me anything about nutrition, diet plans, or healthy eating!</p>
          </div>
        )}
        {messages.map((message, index) => (
          message.role === 'assistant' ? (
            <AiMessage key={index} content={message.content} />
          ) : message.role === 'user' ? (
            <UserMessage key={index} content={message.content} />
          ) : null
        ))}
        {isLoading && (
          <div className="flex gap-3 items-start">
            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
              <Bot className="h-5 w-5 text-green-600" />
            </div>
            <div className="bg-gray-100 rounded-2xl px-4 py-2">
              <Loader2 className="h-5 w-5 animate-spin text-gray-600" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <ChatInput onSend={handleSendMessage} isLoading={isLoading} />
    </div>
  );
}