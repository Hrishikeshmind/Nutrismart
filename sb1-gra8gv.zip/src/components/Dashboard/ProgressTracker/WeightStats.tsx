import React from 'react';
import { ArrowUp, ArrowDown, Minus } from 'lucide-react';

interface WeightStatsProps {
  entries: Array<{ date: string; weight: number }>;
}

export default function WeightStats({ entries }: WeightStatsProps) {
  if (entries.length < 2) return null;

  const calculateStats = () => {
    const sortedEntries = [...entries].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    const monthAgo = new Date();
    monthAgo.setMonth(monthAgo.getMonth() - 1);

    const lastMonth = sortedEntries.filter(entry => 
      new Date(entry.date) >= monthAgo
    );

    const current = sortedEntries[sortedEntries.length - 1].weight;
    const start = sortedEntries[0].weight;
    const monthChange = lastMonth.length >= 2 
      ? current - lastMonth[0].weight
      : 0;

    const weeklyAvg = monthChange / 4;

    return {
      totalChange: current - start,
      monthlyChange: monthChange,
      weeklyAverage: weeklyAvg,
      trend: weeklyAvg < -0.5 ? 'fast' : weeklyAvg > -0.25 ? 'slow' : 'good'
    };
  };

  const stats = calculateStats();
  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'fast': return 'text-yellow-600';
      case 'slow': return 'text-blue-600';
      default: return 'text-green-600';
    }
  };

  const getTrendIcon = (value: number) => {
    if (value === 0) return <Minus className="h-4 w-4" />;
    return value < 0 ? <ArrowDown className="h-4 w-4" /> : <ArrowUp className="h-4 w-4" />;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <h4 className="text-sm font-medium text-gray-600 mb-2">Total Change</h4>
        <div className="flex items-center gap-2">
          {getTrendIcon(stats.totalChange)}
          <span className="text-xl font-bold">
            {Math.abs(stats.totalChange).toFixed(1)} kg
          </span>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <h4 className="text-sm font-medium text-gray-600 mb-2">30-Day Change</h4>
        <div className="flex items-center gap-2">
          {getTrendIcon(stats.monthlyChange)}
          <span className="text-xl font-bold">
            {Math.abs(stats.monthlyChange).toFixed(1)} kg
          </span>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg border border-gray-200">
        <h4 className="text-sm font-medium text-gray-600 mb-2">Weekly Average</h4>
        <div className="flex items-center gap-2">
          {getTrendIcon(stats.weeklyAverage)}
          <span className={`text-xl font-bold ${getTrendColor(stats.trend)}`}>
            {Math.abs(stats.weeklyAverage).toFixed(1)} kg/week
          </span>
        </div>
      </div>
    </div>
  );
}