import React, { useState } from 'react';
import { Target, Calendar } from 'lucide-react';

interface GoalSetterProps {
  currentWeight: number;
  goalWeight: number;
  onSetGoal: (goal: { weight: number; date: string }) => void;
}

export default function GoalSetter({ currentWeight, goalWeight, onSetGoal }: GoalSetterProps) {
  const [weight, setWeight] = useState(goalWeight.toString());
  const [date, setDate] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!weight || !date) return;
    onSetGoal({ weight: Number(weight), date });
  };

  // Calculate recommended date based on safe weight loss rate (0.5-1kg per week)
  const getRecommendedDate = () => {
    const weightToLose = currentWeight - Number(weight);
    const weeksNeeded = Math.ceil(weightToLose / 0.5); // Using 0.5kg/week as safe rate
    const recommendedDate = new Date();
    recommendedDate.setDate(recommendedDate.getDate() + (weeksNeeded * 7));
    return recommendedDate.toISOString().split('T')[0];
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
      <div className="flex items-center gap-3 mb-4">
        <Target className="h-6 w-6 text-green-600" />
        <h3 className="text-lg font-semibold text-gray-900">Set Weight Goal</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Target Weight (kg)
          </label>
          <input
            type="number"
            step="0.1"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="w-full border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
            placeholder="Enter target weight"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Target Date
          </label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="date"
              value={date}
              min={new Date().toISOString().split('T')[0]}
              onChange={(e) => setDate(e.target.value)}
              className="w-full pl-10 border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
            />
          </div>
        </div>

        <div className="text-sm text-gray-600">
          <p>Recommended target date: {getRecommendedDate()}</p>
          <p className="mt-1">Based on a healthy weight loss rate of 0.5kg per week</p>
        </div>

        <button
          type="submit"
          className="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
        >
          Set Goal
        </button>
      </form>
    </div>
  );
}