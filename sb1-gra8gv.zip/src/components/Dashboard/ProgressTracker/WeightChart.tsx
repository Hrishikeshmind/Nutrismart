import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

interface WeightChartProps {
  data: Array<{
    date: string;
    weight: number;
  }>;
  goal: {
    weight: number;
    date: string;
  };
}

export default function WeightChart({ data, goal }: WeightChartProps) {
  // Add goal point to chart data
  const chartData = [
    ...data,
    { date: goal.date, weight: goal.weight, isGoal: true }
  ].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const minWeight = Math.min(...chartData.map(d => d.weight)) - 1;
  const maxWeight = Math.max(...chartData.map(d => d.weight)) + 1;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload || !payload.length) return null;

    const data = payload[0].payload;
    return (
      <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
        <p className="text-sm text-gray-600">{new Date(label).toLocaleDateString()}</p>
        <p className="text-lg font-semibold text-gray-900">
          {data.weight.toFixed(1)} kg
        </p>
        {data.isGoal && (
          <p className="text-sm text-green-600">Goal Weight</p>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Weight History</h3>
      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis 
              dataKey="date" 
              stroke="#6B7280"
              tick={{ fontSize: 12 }}
              tickFormatter={(date) => new Date(date).toLocaleDateString()}
            />
            <YAxis 
              domain={[minWeight, maxWeight]}
              stroke="#6B7280"
              tick={{ fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine
              y={goal.weight}
              stroke="#16A34A"
              strokeDasharray="3 3"
              label={{ 
                value: 'Goal Weight',
                position: 'right',
                fill: '#16A34A',
                fontSize: 12
              }}
            />
            <Line
              type="monotone"
              dataKey="weight"
              stroke="#16A34A"
              strokeWidth={2}
              dot={{ fill: '#16A34A', strokeWidth: 2 }}
              activeDot={{ r: 6, fill: '#16A34A' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}