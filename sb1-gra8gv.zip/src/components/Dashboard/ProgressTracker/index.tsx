import React, { useState } from 'react';
import { Scale, Target, TrendingUp, Plus } from 'lucide-react';
import WeightChart from './WeightChart';
import WeightStats from './WeightStats';
import GoalSetter from './GoalSetter';

interface WeightEntry {
  date: string;
  weight: number;
}

interface WeightGoal {
  weight: number;
  date: string;
}

export default function ProgressTracker() {
  const [weightEntries, setWeightEntries] = useState<WeightEntry[]>([
    { date: '2024-03-01', weight: 80 },
    { date: '2024-03-08', weight: 79.5 },
    { date: '2024-03-15', weight: 78.8 },
    { date: '2024-03-22', weight: 78.2 },
  ]);
  const [newWeight, setNewWeight] = useState('');
  const [goal, setGoal] = useState<WeightGoal>({ weight: 75, date: '2024-06-22' });

  const addWeightEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWeight) return;

    const today = new Date().toISOString().split('T')[0];
    const newEntry = { date: today, weight: Number(newWeight) };
    
    // Sort entries by date
    const updatedEntries = [...weightEntries, newEntry]
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    setWeightEntries(updatedEntries);
    setNewWeight('');
  };

  const latestWeight = weightEntries[weightEntries.length - 1]?.weight || 0;
  const startWeight = weightEntries[0]?.weight || 0;
  const weightChange = startWeight - latestWeight;
  const weeklyChange = weightEntries.length > 1 
    ? latestWeight - weightEntries[weightEntries.length - 2].weight
    : 0;

  // Calculate progress towards goal
  const remainingWeight = latestWeight - goal.weight;
  const totalWeightToLose = startWeight - goal.weight;
  const progressPercentage = Math.min(
    Math.max(((totalWeightToLose - remainingWeight) / totalWeightToLose) * 100, 0),
    100
  );

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Progress Tracker</h2>
        <form onSubmit={addWeightEntry} className="flex items-center gap-2">
          <input
            type="number"
            step="0.1"
            value={newWeight}
            onChange={(e) => setNewWeight(e.target.value)}
            placeholder="Enter weight"
            className="w-32 border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
          />
          <button
            type="submit"
            className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
          >
            <Plus className="h-5 w-5" />
            Add Entry
          </button>
        </form>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <Scale className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Current Weight</h3>
          </div>
          <p className="text-3xl font-bold text-gray-900">{latestWeight.toFixed(1)} kg</p>
          <p className="text-sm text-green-600">{weightChange > 0 ? '-' : '+'}{Math.abs(weightChange).toFixed(1)} kg from start</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <Target className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Goal Progress</h3>
          </div>
          <p className="text-3xl font-bold text-gray-900">{goal.weight.toFixed(1)} kg</p>
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-600 mt-1">{progressPercentage.toFixed(0)}% complete</p>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Weekly Progress</h3>
          </div>
          <p className="text-3xl font-bold text-green-600">{weeklyChange.toFixed(1)} kg</p>
          <p className="text-sm text-gray-600">Last 7 days</p>
        </div>
      </div>

      <div className="mb-8">
        <WeightStats entries={weightEntries} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <WeightChart data={weightEntries} goal={goal} />
        </div>
        <div>
          <GoalSetter
            currentWeight={latestWeight}
            goalWeight={goal.weight}
            onSetGoal={setGoal}
          />
        </div>
      </div>
    </div>
  );
}