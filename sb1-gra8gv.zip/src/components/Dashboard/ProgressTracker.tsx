import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Scale, Target, TrendingUp } from 'lucide-react';

const mockData = [
  { date: '2024-03-01', weight: 80 },
  { date: '2024-03-08', weight: 79.5 },
  { date: '2024-03-15', weight: 78.8 },
  { date: '2024-03-22', weight: 78.2 },
];

export default function ProgressTracker() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Progress Tracker</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <Scale className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Current Weight</h3>
          </div>
          <p className="text-3xl font-bold text-gray-900">78.2 kg</p>
          <p className="text-sm text-green-600">-1.8 kg from start</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <Target className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Goal Weight</h3>
          </div>
          <p className="text-3xl font-bold text-gray-900">75 kg</p>
          <p className="text-sm text-gray-600">3.2 kg to go</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="h-6 w-6 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Weekly Progress</h3>
          </div>
          <p className="text-3xl font-bold text-green-600">-0.6 kg</p>
          <p className="text-sm text-gray-600">Last 7 days</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Weight History</h3>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mockData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={['dataMin - 1', 'dataMax + 1']} />
              <Tooltip />
              <Line type="monotone" dataKey="weight" stroke="#16a34a" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}