import React, { useState } from 'react';
import { Calendar, Plus, Trash2 } from 'lucide-react';

interface Meal {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  time: string;
}

export default function MealPlanner() {
  const [meals, setMeals] = useState<Meal[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const addMeal = () => {
    const newMeal: Meal = {
      id: Date.now().toString(),
      name: '',
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      time: '12:00',
    };
    setMeals([...meals, newMeal]);
  };

  const updateMeal = (id: string, updates: Partial<Meal>) => {
    setMeals(meals.map((meal) => (meal.id === id ? { ...meal, ...updates } : meal)));
  };

  const deleteMeal = (id: string) => {
    setMeals(meals.filter((meal) => meal.id !== id));
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Meal Planner</h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-gray-500" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
            />
          </div>
          <button
            onClick={addMeal}
            className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
          >
            <Plus className="h-5 w-5" />
            Add Meal
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {meals.map((meal) => (
          <div
            key={meal.id}
            className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm"
          >
            <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
              <div className="md:col-span-2">
                <input
                  type="text"
                  placeholder="Meal name"
                  value={meal.name}
                  onChange={(e) => updateMeal(meal.id, { name: e.target.value })}
                  className="w-full border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
                />
              </div>
              <div>
                <input
                  type="number"
                  placeholder="Calories"
                  value={meal.calories || ''}
                  onChange={(e) => updateMeal(meal.id, { calories: Number(e.target.value) })}
                  className="w-full border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
                />
              </div>
              <div>
                <input
                  type="time"
                  value={meal.time}
                  onChange={(e) => updateMeal(meal.id, { time: e.target.value })}
                  className="w-full border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
                />
              </div>
              <div>
                <select
                  className="w-full border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
                >
                  <option>Breakfast</option>
                  <option>Lunch</option>
                  <option>Dinner</option>
                  <option>Snack</option>
                </select>
              </div>
              <div>
                <button
                  onClick={() => deleteMeal(meal.id)}
                  className="text-red-600 hover:text-red-700 transition-colors"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}