import React, { useState } from 'react';
import { Calendar, Plus } from 'lucide-react';
import MealCard from './MealCard';
import DailyNutrition from './DailyNutrition';

interface Meal {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  time: string;
  type: string;
}

const DEFAULT_GOALS = {
  calories: 2000,
  protein: 150,
  carbs: 250,
  fat: 70,
};

export default function MealPlanner() {
  const [meals, setMeals] = useState<Meal[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const addMeal = () => {
    const newMeal: Meal = {
      id: Date.now().toString(),
      name: '',
      calories: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      time: '12:00',
      type: 'breakfast',
    };
    setMeals([...meals, newMeal]);
  };

  const updateMeal = (id: string, updates: Partial<Meal>) => {
    setMeals(meals.map((meal) => (meal.id === id ? { ...meal, ...updates } : meal)));
  };

  const deleteMeal = (id: string) => {
    setMeals(meals.filter((meal) => meal.id !== id));
  };

  return (
    <div className="p-6">
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="flex-1 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900">Meal Planner</h2>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-gray-500" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="border-gray-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
                />
              </div>
              <button
                onClick={addMeal}
                className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors"
              >
                <Plus className="h-5 w-5" />
                Add Meal
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {meals.map((meal) => (
              <MealCard
                key={meal.id}
                meal={meal}
                onUpdate={updateMeal}
                onDelete={deleteMeal}
              />
            ))}
            {meals.length === 0 && (
              <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                <p className="text-gray-500">No meals added yet</p>
                <button
                  onClick={addMeal}
                  className="mt-2 text-green-600 hover:text-green-700 font-medium"
                >
                  Add your first meal
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="lg:w-80">
          <DailyNutrition meals={meals} goals={DEFAULT_GOALS} />
        </div>
      </div>
    </div>
  );
}