import React from 'react';

interface MacroCircleProps {
  protein: number;
  carbs: number;
  fat: number;
}

export function MacroCircle({ protein, carbs, fat }: MacroCircleProps) {
  const total = protein + carbs + fat;
  const proteinPercentage = total ? (protein / total) * 100 : 0;
  const carbsPercentage = total ? (carbs / total) * 100 : 0;
  const fatPercentage = total ? (fat / total) * 100 : 0;

  return (
    <div className="flex items-center gap-4">
      <div className="w-16 h-16 rounded-full relative">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="32"
            cy="32"
            r="28"
            stroke="#E5E7EB"
            strokeWidth="8"
            fill="none"
          />
          <circle
            cx="32"
            cy="32"
            r="28"
            stroke="#22C55E"
            strokeWidth="8"
            fill="none"
            strokeDasharray={`${proteinPercentage * 1.76} 176`}
          />
          <circle
            cx="32"
            cy="32"
            r="28"
            stroke="#3B82F6"
            strokeWidth="8"
            fill="none"
            strokeDasharray={`${carbsPercentage * 1.76} 176`}
            strokeDashoffset={-proteinPercentage * 1.76}
          />
          <circle
            cx="32"
            cy="32"
            r="28"
            stroke="#EF4444"
            strokeWidth="8"
            fill="none"
            strokeDasharray={`${fatPercentage * 1.76} 176`}
            strokeDashoffset={-(proteinPercentage + carbsPercentage) * 1.76}
          />
        </svg>
      </div>
      <div className="flex gap-4 text-sm">
        <div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-gray-600">Protein</span>
          </div>
          <span className="font-semibold">{Math.round(proteinPercentage)}%</span>
        </div>
        <div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <span className="text-gray-600">Carbs</span>
          </div>
          <span className="font-semibold">{Math.round(carbsPercentage)}%</span>
        </div>
        <div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span className="text-gray-600">Fat</span>
          </div>
          <span className="font-semibold">{Math.round(fatPercentage)}%</span>
        </div>
      </div>
    </div>
  );
}