import React from 'react';
import { Circle } from 'lucide-react';

interface DailyNutritionProps {
  meals: Array<{
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }>;
  goals: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
}

export default function DailyNutrition({ meals, goals }: DailyNutritionProps) {
  const totals = meals.reduce(
    (acc, meal) => ({
      calories: acc.calories + (meal.calories || 0),
      protein: acc.protein + (meal.protein || 0),
      carbs: acc.carbs + (meal.carbs || 0),
      fat: acc.fat + (meal.fat || 0),
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const getPercentage = (current: number, goal: number) => 
    Math.min(Math.round((current / goal) * 100), 100);

  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Daily Nutrition</h3>
      
      <div className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-600">Calories</span>
            <span className="font-medium">{totals.calories} / {goals.calories}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-green-600 h-2 rounded-full"
              style={{ width: `${getPercentage(totals.calories, goals.calories)}%` }}
            ></div>
          </div>
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-600">Protein</span>
            <span className="font-medium">{totals.protein}g / {goals.protein}g</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-green-600 h-2 rounded-full"
              style={{ width: `${getPercentage(totals.protein, goals.protein)}%` }}
            ></div>
          </div>
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-600">Carbs</span>
            <span className="font-medium">{totals.carbs}g / {goals.carbs}g</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-500 h-2 rounded-full"
              style={{ width: `${getPercentage(totals.carbs, goals.carbs)}%` }}
            ></div>
          </div>
        </div>

        <div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-600">Fat</span>
            <span className="font-medium">{totals.fat}g / {goals.fat}g</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-red-500 h-2 rounded-full"
              style={{ width: `${getPercentage(totals.fat, goals.fat)}%` }}
            ></div>
          </div>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Circle className="h-4 w-4 text-green-500 fill-current" />
          <span>{Math.round((totals.calories / goals.calories) * 100)}% of daily goal</span>
        </div>
      </div>
    </div>
  );
}