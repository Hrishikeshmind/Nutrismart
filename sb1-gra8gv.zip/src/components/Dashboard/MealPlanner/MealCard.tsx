import React from 'react';
import { Trash2, Edit2 } from 'lucide-react';
import { MacroCircle } from './MacroCircle';

interface MealCardProps {
  meal: {
    id: string;
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    time: string;
    type: string;
  };
  onUpdate: (id: string, updates: any) => void;
  onDelete: (id: string) => void;
}

export default function MealCard({ meal, onUpdate, onDelete }: MealCardProps) {
  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <input
            type="text"
            value={meal.name}
            onChange={(e) => onUpdate(meal.id, { name: e.target.value })}
            className="text-lg font-semibold text-gray-900 border-none focus:ring-0 p-0 bg-transparent"
            placeholder="Enter meal name"
          />
          <div className="flex items-center gap-3 text-sm text-gray-500 mt-1">
            <input
              type="time"
              value={meal.time}
              onChange={(e) => onUpdate(meal.id, { time: e.target.value })}
              className="border-none focus:ring-0 p-0 bg-transparent"
            />
            <select
              value={meal.type}
              onChange={(e) => onUpdate(meal.id, { type: e.target.value })}
              className="border-none focus:ring-0 p-0 bg-transparent"
            >
              <option value="breakfast">Breakfast</option>
              <option value="lunch">Lunch</option>
              <option value="dinner">Dinner</option>
              <option value="snack">Snack</option>
            </select>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="text-gray-400 hover:text-gray-600">
            <Edit2 className="h-4 w-4" />
          </button>
          <button 
            onClick={() => onDelete(meal.id)}
            className="text-gray-400 hover:text-red-600"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-500 mb-1">Calories</label>
          <input
            type="number"
            value={meal.calories || ''}
            onChange={(e) => onUpdate(meal.id, { calories: Number(e.target.value) })}
            className="w-full border-gray-200 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
            placeholder="0"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-500 mb-1">Protein (g)</label>
          <input
            type="number"
            value={meal.protein || ''}
            onChange={(e) => onUpdate(meal.id, { protein: Number(e.target.value) })}
            className="w-full border-gray-200 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
            placeholder="0"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-500 mb-1">Carbs (g)</label>
          <input
            type="number"
            value={meal.carbs || ''}
            onChange={(e) => onUpdate(meal.id, { carbs: Number(e.target.value) })}
            className="w-full border-gray-200 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
            placeholder="0"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-500 mb-1">Fat (g)</label>
          <input
            type="number"
            value={meal.fat || ''}
            onChange={(e) => onUpdate(meal.id, { fat: Number(e.target.value) })}
            className="w-full border-gray-200 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
            placeholder="0"
          />
        </div>
      </div>

      <div className="mt-4">
        <MacroCircle protein={meal.protein} carbs={meal.carbs} fat={meal.fat} />
      </div>
    </div>
  );
}