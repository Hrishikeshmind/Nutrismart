import React from 'react';
import { ArrowRight, Brain, Utensils, LineChart } from 'lucide-react';

export default function Hero() {
  return (
    <div className="pt-24 pb-16 bg-gradient-to-b from-green-50 to-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 space-y-8">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Your Personal
              <span className="text-green-600"> AI Nutritionist</span>
              <br />
              Available 24/7
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl">
              Get personalized nutrition plans powered by AI. We analyze your goals, preferences, and lifestyle to create the perfect meal plan for you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-green-600 text-white px-8 py-3 rounded-full hover:bg-green-700 transition-colors flex items-center justify-center gap-2 text-lg">
                Start Your Journey
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="border-2 border-green-600 text-green-600 px-8 py-3 rounded-full hover:bg-green-50 transition-colors text-lg">
                Learn More
              </button>
            </div>
          </div>
          
          <div className="flex-1 grid grid-cols-2 gap-4 max-w-lg">
            <div className="bg-white p-6 rounded-2xl shadow-lg transform hover:-translate-y-1 transition-transform">
              <Brain className="h-8 w-8 text-green-600 mb-3" />
              <h3 className="font-semibold text-lg mb-2">AI-Powered</h3>
              <p className="text-gray-600">Smart recommendations based on your data</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-lg transform hover:-translate-y-1 transition-transform">
              <Utensils className="h-8 w-8 text-green-600 mb-3" />
              <h3 className="font-semibold text-lg mb-2">Custom Plans</h3>
              <p className="text-gray-600">Tailored to your dietary preferences</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-lg transform hover:-translate-y-1 transition-transform col-span-2">
              <LineChart className="h-8 w-8 text-green-600 mb-3" />
              <h3 className="font-semibold text-lg mb-2">Progress Tracking</h3>
              <p className="text-gray-600">Monitor your journey with detailed analytics</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}