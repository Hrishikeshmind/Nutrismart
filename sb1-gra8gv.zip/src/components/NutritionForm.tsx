import React, { useState } from 'react';
import { ChevronRight, Loader2, Bot, Calculator } from 'lucide-react';
import { generateNutritionPlan } from '../services/nutritionService';
import type { NutritionFormData } from '../services/types';

export default function NutritionForm() {
  const [formData, setFormData] = useState<NutritionFormData>({
    age: 0,
    weight: 0,
    dietaryPreferences: '',
    healthGoals: []
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    plan: string;
    source: 'ai' | 'calculator';
    notice?: string;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGoalChange = (goal: string) => {
    setFormData(prev => ({
      ...prev,
      healthGoals: prev.healthGoals.includes(goal)
        ? prev.healthGoals.filter(g => g !== goal)
        : [...prev.healthGoals, goal]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.age <= 0 || formData.weight <= 0 || !formData.dietaryPreferences || formData.healthGoals.length === 0) {
      setError('Please fill in all required fields');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await generateNutritionPlan(formData);
      setResult(response);
    } catch (err: any) {
      setError(err.message || 'Failed to generate nutrition plan. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-20 bg-green-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Get Your Personalized Plan
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Age
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="120"
                  value={formData.age || ''}
                  onChange={e => setFormData(prev => ({ ...prev, age: parseInt(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Enter your age"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="300"
                  value={formData.weight || ''}
                  onChange={e => setFormData(prev => ({ ...prev, weight: parseInt(e.target.value) || 0 }))}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Enter your weight"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Dietary Preferences
              </label>
              <select
                required
                value={formData.dietaryPreferences}
                onChange={e => setFormData(prev => ({ ...prev, dietaryPreferences: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">Select your diet type</option>
                <option value="omnivore">Omnivore</option>
                <option value="vegetarian">Vegetarian</option>
                <option value="vegan">Vegan</option>
                <option value="keto">Keto</option>
                <option value="paleo">Paleo</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Health Goals (select at least one)
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {['Weight Loss', 'Muscle Gain', 'Maintenance', 'Better Health', 'More Energy', 'Sports Performance'].map((goal) => (
                  <label key={goal} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.healthGoals.includes(goal)}
                      onChange={() => handleGoalChange(goal)}
                      className="rounded text-green-600 focus:ring-green-500"
                    />
                    <span className="text-sm text-gray-700">{goal}</span>
                  </label>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Generating Plan...
                </>
              ) : (
                <>
                  Generate Your Plan
                  <ChevronRight className="h-5 w-5" />
                </>
              )}
            </button>
          </form>

          {error && (
            <div className="mt-6 p-4 bg-red-50 border border-red-100 rounded-lg text-red-700">
              {error}
            </div>
          )}

          {result && (
            <div className="mt-6">
              {result.notice && (
                <div className="mb-4 p-4 bg-blue-50 border border-blue-100 rounded-lg text-blue-700 flex items-start gap-3">
                  {result.source === 'calculator' ? (
                    <Calculator className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  ) : (
                    <Bot className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  )}
                  <p>{result.notice}</p>
                </div>
              )}
              
              <div className="p-6 bg-green-50 border border-green-100 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Your Personalized Nutrition Plan</h3>
                <div className="prose prose-green">
                  {result.plan.split('\n').map((line, index) => (
                    <p key={index} className="mb-2">{line}</p>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}