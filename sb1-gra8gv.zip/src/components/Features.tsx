import React from 'react';
import { 
  Brain, 
  Utensils, 
  LineChart, 
  Calendar, 
  ShoppingCart, 
  MessageSquare 
} from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'AI Analysis',
    description: 'Our AI analyzes your health data to create perfectly balanced meal plans'
  },
  {
    icon: Utensils,
    title: 'Custom Recipes',
    description: 'Get personalized recipes that match your dietary preferences and restrictions'
  },
  {
    icon: LineChart,
    title: 'Progress Tracking',
    description: 'Monitor your nutrition goals with detailed charts and insights'
  },
  {
    icon: Calendar,
    title: 'Meal Planning',
    description: 'Weekly meal plans that adapt to your schedule and preferences'
  },
  {
    icon: ShoppingCart,
    title: 'Shopping Lists',
    description: 'Automated grocery lists based on your meal plans'
  },
  {
    icon: MessageSquare,
    title: '24/7 Support',
    description: 'Get nutrition advice whenever you need it with our AI chat'
  }
];

export default function Features() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Powered by Advanced AI Technology
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Experience the future of nutrition planning with our comprehensive feature set
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="p-6 bg-white rounded-2xl border border-gray-100 hover:border-green-200 transition-colors"
            >
              <feature.icon className="h-10 w-10 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}